import { Fragment, useEffect, useRef, useState } from "react";
import { FiMoreVertical, FiSearch, FiX } from "react-icons/fi";
import Contenedor from "../../componentesReuse/Contenedor";
import Boton from "../../componentesReuse/Boton";
import ModalAdmin from "../componentes/ModalAdmin";
import VariantesProducto from "../componentes/VariantesProducto";
import SelectorImagen from "../componentes/SelectorImagen";
import {
  obtenerProductos,
  obtenerCatalogosProducto,
  obtenerOpcionesProducto,
  obtenerResumenProductos,
  crearProducto,
  actualizarProducto,
  cambiarEstadoProducto,
  eliminarProducto,
  crearVariante,
  actualizarVariante,
  buscarProductos,
  buscarVariantes,
  buscarProductosPorNombre,
  analizarCoincidenciasNombre,
} from "../servicios/productosService";
import { useAuth } from "../contexto/AuthContext";
import "../../estilos/admin-productos.css";
const TALLES_ALFABETICOS = ["XXS", "XS", "S", "M", "L", "XL", "XXL", "XXXL"];
const TALLES_NUMERICOS = [
  "24",
  "25",
  "26",
  "27",
  "28",
  "29",
  "30",
  "31",
  "32",
  "33",
  "34",
  "35",
  "36",
  "38",
  "40",
  "42",
  "44",
  "46",
  "48",
  "50",
  "52",
  "54",
  "56",
  "58",
  "60",
];
const FORM_PRODUCTO_INICIAL = {
  nombre: "",
  marca: "",
  tipoProducto: "",
  genero: "",
  descripcion: "",
  activo: true,
};
const FORM_VARIANTE_INICIAL = {
  productoId: "",
  color: "",
  talle: "",
  barcode: "",
  precio: "",
  activo: true,
};
function normalizarBusqueda(valor) {
  return String(valor || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}
function obtenerValoresSinRepetidos(...listas) {
  const valores = listas.flat();
  const mapa = new Map();
  valores.forEach((valor) => {
    const nombre = typeof valor === "string" ? valor : valor?.nombre;
    if (!nombre) {
      return;
    }
    const clave = normalizarBusqueda(nombre);
    if (!mapa.has(clave)) {
      mapa.set(clave, nombre);
    }
  });
  return Array.from(mapa.values());
}
function filtrarSugerencias(valores, busqueda) {
  const termino = normalizarBusqueda(busqueda);
  if (!termino) {
    return [];
  }
  return valores.filter((valor) =>
    normalizarBusqueda(valor).startsWith(termino),
  );
}
function obtenerValorCanonico(valores, valorIngresado) {
  const termino = normalizarBusqueda(valorIngresado);
  if (!termino) {
    return valorIngresado;
  }
  const coincidenciaExacta = valores.find(
    (valor) => normalizarBusqueda(valor) === termino,
  );
  if (coincidenciaExacta) {
    return coincidenciaExacta;
  }
  const coincidenciasParciales = valores.filter((valor) =>
    normalizarBusqueda(valor).startsWith(termino),
  );
  if (coincidenciasParciales.length === 1) {
    return coincidenciasParciales[0];
  }
  return valorIngresado;
}
const IMAGEN_VACIA = { archivo: null, actual: null, quitar: false };
const TAMANIO_PAGINA = 50;
function Productos() {
  const { puede } = useAuth();
  const puedeModificarPrecios = puede("ModificarPrecios");
  const puedeEliminarProductos = puede("DeleteProduct");
  const [productos, setProductos] = useState([]);
  const [resumenProductos, setResumenProductos] = useState([]);
  const [catalogosProducto, setCatalogosProducto] = useState(null);
  const [opcionesProducto, setOpcionesProducto] = useState({
    color: null,
    talle: null,
  });
  const [cargando, setCargando] = useState(true);
  const [cargandoOpciones, setCargandoOpciones] = useState(false);
  const [error, setError] = useState(null);
  const [mensajeExito, setMensajeExito] = useState("");
  const [modalAbierto, setModalAbierto] = useState(null);
  const [guardando, setGuardando] = useState(false);
  const [productoEditandoId, setProductoEditandoId] = useState(null);
  const [productoConfirmarEstado, setProductoConfirmarEstado] = useState(null);
  const [productoEliminar, setProductoEliminar] = useState(null);
  const [procesandoProductoId, setProcesandoProductoId] = useState(null);
  const [advertenciasNombre, setAdvertenciasNombre] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [busquedaVariantes, setBusquedaVariantes] = useState("");
  const modoVariantes = Boolean(busquedaVariantes.trim());
  const [buscando, setBuscando] = useState(false);
  const [pagina, setPagina] = useState(1);
  const [totalResultados, setTotalProductos] = useState(0);
  const [filtroMarca, setFiltroMarca] = useState("");
  const [filtroTipoProducto, setFiltroTipoProducto] = useState("");
  const [menuAccionesAbiertoId, setMenuAccionesAbiertoId] = useState(null);
  const [formProducto, setFormProducto] = useState(FORM_PRODUCTO_INICIAL);
  const [formVariante, setFormVariante] = useState(FORM_VARIANTE_INICIAL);
  const [varianteEditandoId, setVarianteEditandoId] = useState(null);
  const [imagenVariante, setImagenVariante] = useState(IMAGEN_VACIA);
  const [galeria, setGaleria] = useState({ actuales: [], archivos: [], modificada: false });
  const [productoVariantesAbiertoId, setProductoVariantesAbiertoId] =
    useState(null);
  const [colorSeleccionado, setColorSeleccionado] = useState(false);
  const primeraCargaListado = useRef(true);
  const solicitudListadoRef = useRef(0);
  const cargarDatosRef = useRef(null);
  const totalPaginas = Math.max(
    1,
    Math.ceil(totalResultados / TAMANIO_PAGINA),
  );
  function cambiarPagina(paginaNueva) {
    if (paginaNueva < 1 || paginaNueva > totalPaginas) {
      return;
    }
    setPagina(paginaNueva);
    setBuscando(true);
    cargarDatos(busqueda, false, paginaNueva, {
      marca: filtroMarca,
      tipoProducto: filtroTipoProducto,
    });
  }
  // Las dos búsquedas y los filtros usan una sola consulta por cambio.
  useEffect(() => {
    if (primeraCargaListado.current) {
      primeraCargaListado.current = false;
      return;
    }
    solicitudListadoRef.current += 1;
    setBuscando(true);
    const temporizador = setTimeout(() => {
      setPagina(1);
      cargarDatosRef.current(busqueda, false, 1, {
        marca: filtroMarca,
        tipoProducto: filtroTipoProducto,
      });
    }, 350);
    return () => clearTimeout(temporizador);
  }, [busqueda, busquedaVariantes, filtroMarca, filtroTipoProducto]);
  useEffect(() => {
    cargarDatos();
    // La carga inicial ya se resuelve con los valores por defecto.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  async function cargarDatos(
    terminoBusqueda = "",
    actualizarResumen = true,
    paginaActual = pagina,
    filtros = { marca: filtroMarca, tipoProducto: filtroTipoProducto },
  ) {
    const solicitud = ++solicitudListadoRef.current;
    setError(null);
    const marcas = filtros.marca ? [filtros.marca] : [];
    const tiposProducto = filtros.tipoProducto ? [filtros.tipoProducto] : [];
    try {
      const [respuestaProductos, respuestaCatalogosProducto, nuevoResumen] =
        await Promise.all([
          consultarProductosListado({
            pagina: paginaActual,
            termino: terminoBusqueda,
            marcas,
            tiposProducto,
          }),
          obtenerCatalogosProducto(),
          actualizarResumen ? obtenerResumenProductos() : Promise.resolve(null),
        ]);
      if (solicitud !== solicitudListadoRef.current) return;
      setProductos(respuestaProductos.productos);
      setTotalProductos(respuestaProductos.total);
      // Si la página quedó vacía y no es la primera, retrocedemos hasta
      // encontrar una con contenido (pasa al borrar el último de una página).
      const ultimaPagina = Math.max(
        1,
        Math.ceil(respuestaProductos.total / TAMANIO_PAGINA),
      );
      if (paginaActual > ultimaPagina && ultimaPagina > 0) {
        setPagina(ultimaPagina);
        await cargarDatos(
          terminoBusqueda,
          actualizarResumen,
          ultimaPagina,
          filtros,
        );
        return;
      }
      if (nuevoResumen) {
        setResumenProductos(nuevoResumen);
      }
      setCatalogosProducto(respuestaCatalogosProducto);
    } catch (err) {
      if (solicitud === solicitudListadoRef.current) setError(err.message);
    } finally {
      if (solicitud === solicitudListadoRef.current) {
        setCargando(false);
        setBuscando(false);
      }
    }
  }
  function consultarProductosListado({
    pagina: paginaPedida,
    termino,
    marcas,
    tiposProducto,
  }) {
    if (modoVariantes) {
      return buscarVariantes(busquedaVariantes.trim(), {
        pagina: paginaPedida,
        take: TAMANIO_PAGINA,
        marcas,
        tiposProducto,
      });
    }
    return termino.trim()
      ? buscarProductos(termino.trim(), {
          pagina: paginaPedida,
          take: TAMANIO_PAGINA,
          marcas,
          tiposProducto,
        })
      : obtenerProductos({
          pagina: paginaPedida,
          take: TAMANIO_PAGINA,
          marcas,
          tiposProducto,
        });
  }
  cargarDatosRef.current = cargarDatos;
  async function cargarOpcionesProducto(productoId) {
    if (!productoId) {
      setOpcionesProducto({
        color: null,
        talle: null,
      });
      return;
    }
    setCargandoOpciones(true);
    setError(null);
    try {
      const opciones = await obtenerOpcionesProducto(productoId);
      console.log("OPCIONES DEL PRODUCTO:", opciones);
      setOpcionesProducto(opciones);
    } catch (err) {
      setOpcionesProducto({
        color: null,
        talle: null,
      });
      setError(err.message);
    } finally {
      setCargandoOpciones(false);
    }
  }
  function manejarCampoProducto(e) {
    const { name, value, type, checked } = e.target;
    setFormProducto((anterior) => ({
      ...anterior,
      [name]: type === "checkbox" ? checked : value,
    }));
    if (name === "nombre") {
      setAdvertenciasNombre([]);
    }
  }
  function manejarCampoVariante(e) {
    const { name, value, type, checked } = e.target;
    setFormVariante((anterior) => ({
      ...anterior,
      [name]: type === "checkbox" ? checked : value,
    }));
    if (name === "productoId") {
      setFormVariante((anterior) => ({
        ...anterior,
        productoId: value,
        color: "",
        talle: "",
      }));
      cargarOpcionesProducto(value);
    }
  }
  function seleccionarColor(color) {
    setFormVariante((anterior) => ({
      ...anterior,
      color,
    }));
    setColorSeleccionado(true);
    if (!varianteEditandoId) {
      const variantes = productos.find((p) => String(p.id) === String(formVariante.productoId))?.variantes || [];
      const existente = variantes.find((v) => normalizarBusqueda(v.color) === normalizarBusqueda(color) && v.galeria?.length);
      setGaleria({ actuales: existente?.galeria || [], archivos: [], modificada: false });
    }
  }
  function manejarArchivoVariante(archivo) {
    setImagenVariante((anterior) => ({
      archivo,
      actual: archivo ? anterior.actual : null,
      quitar: archivo ? false : Boolean(anterior.actual?.id),
    }));
  }
  function seleccionarTalle(talle) {
    setFormVariante((anterior) => ({
      ...anterior,
      talle,
    }));
  }
  function normalizarTalleIngresado() {
    setFormVariante((anterior) => ({
      ...anterior,
      talle: obtenerValorCanonico(
        tallesDisponibles,
        anterior.talle,
      ).toUpperCase(),
    }));
  }
  function abrirModalProducto() {
    setProductoEditandoId(null);
    setError(null);
    setMensajeExito("");
    setAdvertenciasNombre([]);
    setFormProducto(FORM_PRODUCTO_INICIAL);
    setModalAbierto("producto");
  }
  function abrirModalEditarProducto(producto) {
    setProductoEditandoId(producto.id);
    setError(null);
    setMensajeExito("");
    setAdvertenciasNombre([]);
    setFormProducto({
      nombre: producto.nombre || "",
      marca: producto.marca || "",
      tipoProducto: producto.tipoProducto || "",
      genero: producto.genero || "",
      descripcion: producto.descripcion || "",
      activo: Boolean(producto.activo),
    });
    setModalAbierto("producto");
  }
  function abrirModalVariante(productoId = "") {
    setVarianteEditandoId(null);
    setError(null);
    setMensajeExito("");
    setColorSeleccionado(false);
    setImagenVariante(IMAGEN_VACIA);
    setGaleria({ actuales: [], archivos: [], modificada: false });
    setFormVariante({
      ...FORM_VARIANTE_INICIAL,
      productoId,
    });
    setOpcionesProducto({
      color: null,
      talle: null,
    });
    setModalAbierto("variante");
    if (productoId) {
      cargarOpcionesProducto(productoId);
    }
  }
  function abrirModalEditarVariante(variante) {
    console.log("VARIANTE A EDITAR:", variante);
    console.log("OPCIONES DE LA VARIANTE:", variante.opciones);
    setVarianteEditandoId(variante.id);
    setError(null);
    setMensajeExito("");
    setColorSeleccionado(true);
    setFormVariante({
      productoId: variante.productoId || "",
      color: variante.color || "",
      talle: variante.talle || "",
      barcode: variante.sku || "",
      precio: variante.precio != null ? variante.precio / 100 : "",
      activo: Boolean(variante.activo),
    });
    setImagenVariante({ archivo: null, actual: variante.imagen || null, quitar: false });
    const otras = productos.find((p) => String(p.id) === String(variante.productoId))?.variantes || [];
    const galeriaColor = otras.find((v) =>
      normalizarBusqueda(v.color) === normalizarBusqueda(variante.color) && v.galeria?.length
    )?.galeria || variante.galeria || [];
    setGaleria({ actuales: galeriaColor, archivos: [], modificada: false });
    setOpcionesProducto({
      color: null,
      talle: null,
    });
    setModalAbierto("variante");
    if (variante.productoId) {
      cargarOpcionesProducto(variante.productoId);
    }
  }
  function cerrarModal() {
    if (guardando) {
      return;
    }
    setModalAbierto(null);
    setError(null);
    setMensajeExito("");
    setAdvertenciasNombre([]);
    setColorSeleccionado(false);
    setImagenVariante(IMAGEN_VACIA);
    setGaleria({ actuales: [], archivos: [], modificada: false });
    setOpcionesProducto({
      color: null,
      talle: null,
    });
  }
  async function manejarCrearProducto(e) {
    e.preventDefault();
    setGuardando(true);
    setError(null);
    setMensajeExito("");
    try {
      if (productoEditandoId) {
        await actualizarProducto({
          productId: productoEditandoId,
          nombre: formProducto.nombre,
          marca: formProducto.marca,
          genero: formProducto.genero,
          tipoProducto: formProducto.tipoProducto,
          descripcion: formProducto.descripcion,
          activo: formProducto.activo,
        });
        setMensajeExito("Producto actualizado correctamente.");
      } else {
        await crearProducto({
          nombre: formProducto.nombre,
          marca: formProducto.marca,
          genero: formProducto.genero,
          tipoProducto: formProducto.tipoProducto,
          descripcion: formProducto.descripcion,
          activo: formProducto.activo,
        });
        setMensajeExito("Producto creado correctamente.");
      }
      setFormProducto(FORM_PRODUCTO_INICIAL);
      setProductoEditandoId(null);
      setAdvertenciasNombre([]);
      await cargarDatos(busqueda);
      setTimeout(() => {
        setModalAbierto(null);
        setMensajeExito("");
      }, 4000);
    } catch (err) {
      setError(err.message);
    } finally {
      setGuardando(false);
    }
  }
  async function manejarCambiarEstadoProducto(producto) {
    setMenuAccionesAbiertoId(null);
    if (producto.activo) {
      setProductoConfirmarEstado(producto);
      return;
    }
    await ejecutarCambioEstadoProducto(producto);
  }
  async function ejecutarCambioEstadoProducto(producto) {
    const nuevoEstado = !producto.activo;
    setProcesandoProductoId(producto.id);
    setError(null);
    setMensajeExito("");
    try {
      await cambiarEstadoProducto({
        productId: producto.id,
        activo: nuevoEstado,
      });
      setMensajeExito(
        nuevoEstado
          ? "Producto activado correctamente."
          : "Producto desactivado correctamente.",
      );
      setProductoConfirmarEstado(null);
      await cargarDatos(busqueda);
      setTimeout(() => {
        setMensajeExito("");
      }, 1500);
    } catch (err) {
      setError(err.message);
    } finally {
      setProcesandoProductoId(null);
    }
  }
  async function ejecutarEliminarProducto(producto) {
    setProcesandoProductoId(producto.id);
    setError(null);
    setMensajeExito("");
    try {
      await eliminarProducto(producto.id);
      setProductoEliminar(null);
      setMenuAccionesAbiertoId(null);
      setMensajeExito("Producto eliminado correctamente.");
      await cargarDatos(busqueda);
      setTimeout(() => {
        setMensajeExito("");
      }, 1500);
    } catch (err) {
      setError(err.message);
    } finally {
      setProcesandoProductoId(null);
    }
  }
  async function manejarCrearVariante(e) {
    e.preventDefault();
    if (!varianteEditandoId && !colorSeleccionado) {
      setError("Debés seleccionar un color de la lista.");
      return;
    }
    const colorNormalizado = obtenerValorCanonico(
      coloresDisponibles,
      formVariante.color.trim(),
    );
    const colorValido = coloresDisponibles.some(
      (color) =>
        normalizarBusqueda(color) === normalizarBusqueda(colorNormalizado),
    );
    if (!colorValido) {
      setError("Debés seleccionar un color válido de la lista.");
      return;
    }
    const talleIngresado = formVariante.talle.trim();
    const talleNormalizado = talleIngresado
      ? obtenerValorCanonico(tallesDisponibles, talleIngresado).toUpperCase()
      : "";
    if (!colorNormalizado) {
      setError("El color es obligatorio.");
      return;
    }
    if (talleNormalizado) {
      const esTalleNumerico = /^\d{1,2}$/.test(talleNormalizado);
      const esTalleAlfabetico = TALLES_ALFABETICOS.includes(talleNormalizado);
      if (!esTalleNumerico && !esTalleAlfabetico) {
        setError(
          "El talle debe ser numérico de hasta 2 dígitos o uno de los talles alfabéticos sugeridos.",
        );
        return;
      }
    }
    const productoSeleccionado = productos.find(
      (producto) => String(producto.id) === String(formVariante.productoId),
    );
    if (!varianteEditandoId) {
      const varianteExistente = productoSeleccionado?.variantes?.some(
        (variante) =>
          normalizarBusqueda(variante.color) ===
            normalizarBusqueda(colorNormalizado) &&
          normalizarBusqueda(variante.talle) ===
            normalizarBusqueda(talleNormalizado),
      );
      if (varianteExistente) {
        setError(
          "Ya existe una variante con ese color y talle para este producto.",
        );
        return;
      }
    }
    setGuardando(true);
    setError(null);
    setMensajeExito("");
    try {
      if (varianteEditandoId) {
        await actualizarVariante({
          variantId: varianteEditandoId,
          sku: formVariante.barcode,
          precio: puedeModificarPrecios ? formVariante.precio : null,
          activo: formVariante.activo,
          imagenArchivo: imagenVariante.archivo,
          imagenActual: imagenVariante.actual,
          quitarImagen: imagenVariante.quitar,
          productId: formVariante.productoId,
          color: colorNormalizado,
          talle: talleNormalizado,
          imagenesActuales: galeria.actuales,
          imagenesArchivos: galeria.archivos,
          galeriaModificada: galeria.modificada,
        });
        setMensajeExito("Variante actualizada correctamente.");
      } else {
        await crearVariante({
          productId: formVariante.productoId,
          color: colorNormalizado,
          talle: talleNormalizado,
          sku: formVariante.barcode,
          // Sin permiso de precios la variante nace sin precio e inactiva.
          precio: puedeModificarPrecios ? formVariante.precio : null,
          activo: puedeModificarPrecios ? formVariante.activo : false,
          imagenArchivo: imagenVariante.archivo,
          imagenesActuales: galeria.actuales,
          imagenesArchivos: galeria.archivos,
        });
        setMensajeExito(
          puedeModificarPrecios
            ? "Variante guardada correctamente."
            : "Variante guardada inactiva. El administrador debe cargar el precio para activarla.",
        );
      }
      setFormVariante(FORM_VARIANTE_INICIAL);
      setVarianteEditandoId(null);
      setColorSeleccionado(false);
      setImagenVariante(IMAGEN_VACIA);
    setGaleria({ actuales: [], archivos: [], modificada: false });
      setOpcionesProducto({ color: null, talle: null });
      await cargarDatos(busqueda);
      setTimeout(() => {
        setModalAbierto(null);
        setMensajeExito("");
      }, 1500);
    } catch (err) {
      setError(err.message);
    } finally {
      setGuardando(false);
    }
  }
  async function manejarCambiarEstadoVariante(variante) {
    setError(null);
    setMensajeExito("");
    try {
      /*
       * Para cambiar solamente el estado de la variante,
       * conservamos sus datos actuales.
       */
      const opcionIds = variante.opciones?.map((opcion) => opcion.id) || [];
      await actualizarVariante({
        variantId: variante.id,
        sku: variante.sku,
        precio: puedeModificarPrecios ? variante.precio / 100 : null,
        activo: !variante.activo,
        optionIds: opcionIds,
      });
      setMensajeExito(
        !variante.activo
          ? "Variante activada correctamente."
          : "Variante desactivada correctamente.",
      );
      await cargarDatos(busqueda);
      setTimeout(() => {
        setMensajeExito("");
      }, 1500);
    } catch (err) {
      setError(err.message);
    }
  }
  async function verificarNombreProducto() {
    const nombre = formProducto.nombre.trim();
    if (!nombre) {
      setAdvertenciasNombre([]);
      return;
    }
    try {
      const productosEncontrados = await buscarProductosPorNombre(nombre);
      const productosSinActual = productoEditandoId
        ? productosEncontrados.filter(
            (producto) => String(producto.id) !== String(productoEditandoId),
          )
        : productosEncontrados;
      const coincidencias = analizarCoincidenciasNombre(
        nombre,
        productosSinActual,
      );
      setAdvertenciasNombre(coincidencias);
    } catch {
      setAdvertenciasNombre([]);
    }
  }
  function alternarVariantesProducto(productoId) {
    setProductoVariantesAbiertoId((productoActualId) =>
      String(productoActualId) === String(productoId) ? null : productoId,
    );
  }
  function alternarMenuAcciones(productoId) {
    setMenuAccionesAbiertoId((idActual) =>
      String(idActual) === String(productoId) ? null : productoId,
    );
  }
  function seleccionarAccion(accion) {
    setMenuAccionesAbiertoId(null);
    accion();
  }
  const tallesExistentesProducto = opcionesProducto.talle?.opciones || [];
  const coloresCatalogo = catalogosProducto?.colores || [];
  const coloresDisponibles = obtenerValoresSinRepetidos(coloresCatalogo);
  const tallesDisponibles = obtenerValoresSinRepetidos(
    TALLES_ALFABETICOS,
    TALLES_NUMERICOS,
    tallesExistentesProducto,
  );
  const tallesSugeridos = filtrarSugerencias(
    tallesDisponibles,
    formVariante.talle,
  );
  const mostrarSugerenciasTalle =
    Boolean(formVariante.talle.trim()) &&
    !tallesDisponibles.some(
      (talle) =>
        normalizarBusqueda(talle) === normalizarBusqueda(formVariante.talle),
    );
  return (
    <main className="estructura">
      <Contenedor>
        <header className="estructura__encabezado">
          <div>
            <h1 className="estructura__titulo">Productos</h1>
          </div>
        </header>
        {error && modalAbierto !== "variante" && (
          <p className="login-admin__error">{error}</p>
        )}
        {mensajeExito && !modalAbierto && (
          <p className="estructura__tarjeta fondo-verde">{mensajeExito}</p>
        )}
        {!cargando && (
          <>
            <section
              className="estructura__resumen"
              aria-label="Resumen de productos"
            >
              {resumenProductos.map((item) => (
                <article className="estructura__tarjeta" key={item.nombre}>
                  <span>{item.nombre}</span>
                  <strong>{item.cantidad}</strong>
                </article>
              ))}
            </section>
            <section className="estructura__panel">
              <div className="estructura__panel-encabezado">
                <h2>{modoVariantes ? "Resultados de variantes" : "Listado de productos"}</h2>
                <div className="estructura__panel-acciones">
                  <Boton variante="admin" onClick={abrirModalProducto}>
                    Nuevo producto
                  </Boton>
                  <Boton variante="admin" onClick={() => abrirModalVariante()}>
                    Nueva variante
                  </Boton>
                </div>
              </div>
              <div className="admin-productos__filtros">
              <div className="admin-productos__buscador">
                <label htmlFor="buscar-productos">Buscar productos</label>
                <div className="admin-productos__buscador-control">
                  <FiSearch aria-hidden="true" />
                  <input
                    id="buscar-productos"
                    type="text"
                    value={busqueda}
                    onChange={(e) => {
                      solicitudListadoRef.current += 1;
                      setBuscando(true);
                      setBusqueda(e.target.value);
                      setBusquedaVariantes("");
                      setProductoVariantesAbiertoId(null);
                    }}
                    placeholder="Nombre del producto"
                    autoComplete="off"
                  />
                  {busqueda && (
                    <button
                      type="button"
                      onClick={() => {
                        solicitudListadoRef.current += 1;
                        setBuscando(true);
                        setBusqueda("");
                        document.getElementById("buscar-productos")?.focus();
                      }}
                      aria-label="Limpiar búsqueda de productos"
                    >
                      <FiX aria-hidden="true" />
                    </button>
                  )}
                </div>
              </div>
              <div className="admin-productos__buscador">
                <label htmlFor="buscar-variantes">Buscar variantes</label>
                <div className="admin-productos__buscador-control">
                  <FiSearch aria-hidden="true" />
                  <input
                    id="buscar-variantes"
                    type="text"
                    value={busquedaVariantes}
                    onChange={(e) => {
                      solicitudListadoRef.current += 1;
                      setBuscando(true);
                      setBusquedaVariantes(e.target.value);
                      setBusqueda("");
                      setProductoVariantesAbiertoId(null);
                    }}
                    placeholder="Nombre o barcode"
                    autoComplete="off"
                  />
                  {busquedaVariantes && (
                    <button
                      type="button"
                      onClick={() => {
                        solicitudListadoRef.current += 1;
                        setBuscando(true);
                        setBusquedaVariantes("");
                        document.getElementById("buscar-variantes")?.focus();
                      }}
                      aria-label="Limpiar búsqueda de variantes"
                    >
                      <FiX aria-hidden="true" />
                    </button>
                  )}
                </div>
              </div>
                <div className="estructura__campo">
                  <label htmlFor="filtro-marca">Marca</label>
                  <select
                    id="filtro-marca"
                    value={filtroMarca}
                    onChange={(e) => setFiltroMarca(e.target.value)}
                  >
                    <option value="">Todas las marcas</option>
                    {catalogosProducto?.marcas.map((marca) => (
                      <option key={marca.id} value={marca.id}>
                        {marca.nombre}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="estructura__campo">
                  <label htmlFor="filtro-tipo-producto">Tipo de producto</label>
                  <select
                    id="filtro-tipo-producto"
                    value={filtroTipoProducto}
                    onChange={(e) => setFiltroTipoProducto(e.target.value)}
                  >
                    <option value="">Todos los tipos</option>
                    {catalogosProducto?.tiposProducto.map((tipoProducto) => (
                      <option key={tipoProducto.id} value={tipoProducto.id}>
                        {tipoProducto.nombre}
                      </option>
                    ))}
                  </select>
                </div>
                {(filtroMarca || filtroTipoProducto) && (
                  <Boton
                    variante="admin"
                    onClick={() => {
                      setFiltroMarca("");
                      setFiltroTipoProducto("");
                    }}
                  >
                    Limpiar filtros
                  </Boton>
                )}
              </div>
              {buscando && <p role="status">Buscando...</p>}
              {!buscando && modoVariantes && (
                <div className="estructura__tabla">
                  {productos.length === 0 && (
                    <p role="status">No se encontraron variantes con la búsqueda y los filtros aplicados.</p>
                  )}
                  {productos.map((producto) => (
                    <section className="estructura__lista-item" key={producto.id}>
                      <strong>{producto.nombre}</strong>
                      <span>{producto.marca || "—"} · {producto.tipoProducto || "—"}</span>
                      <VariantesProducto
                        variantes={producto.variantes}
                        onEditar={abrirModalEditarVariante}
                        onCambiarEstado={manejarCambiarEstadoVariante}
                      />
                    </section>
                  ))}
                </div>
              )}
              {!buscando && !modoVariantes && (
              <div className="estructura__tabla">
                <div className="estructura__tabla-cabecera admin-productos__cabecera">
                  <span>Nombre</span>
                  <span>Marca</span>
                  <span>Género</span>
                  <span>Tipo de producto</span>
                  <span>Variantes</span>
                  <span>Activo</span>
                  <span>Acciones</span>
                </div>
                {productos.length === 0 && (
                  <p>
                    {busqueda || filtroMarca || filtroTipoProducto
                      ? "No se encontraron productos con los filtros aplicados."
                      : "No hay productos para mostrar."}
                  </p>
                )}
                {productos.map((producto) => (
                  <Fragment key={producto.id}>
                    <article className="estructura__tabla-fila admin-productos__fila">
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Nombre
                        </span>
                        <span>{producto.nombre}</span>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Marca
                        </span>
                        <span>{producto.marca || "—"}</span>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Género
                        </span>
                        <span>{producto.genero || "—"}</span>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Tipo de producto
                        </span>
                        <span>{producto.tipoProducto || "—"}</span>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Variantes
                        </span>
                        <Boton
                          variante="admin"
                          type="button"
                          onClick={() => alternarVariantesProducto(producto.id)}
                        >
                          {producto.cantidadVariantes} ·{" "}
                          {String(productoVariantesAbiertoId) ===
                          String(producto.id)
                            ? "Ocultar variantes"
                            : "Mostrar variantes"}
                        </Boton>
                        <Boton
                          className="admin-productos__agregar-variante-mobile"
                          variante="admin"
                          type="button"
                          onClick={() => abrirModalVariante(producto.id)}
                        >
                          Agregar variante
                        </Boton>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Activo
                        </span>
                        <span>{producto.activo ? "Sí" : "No"}</span>
                      </div>
                      <div className="estructura__tabla-dato">
                        <span className="estructura__tabla-etiqueta">
                          Acciones
                        </span>
                        <div className="admin-productos__acciones-mobile">
                          <button
                            className="admin-productos__acciones-disparador"
                            type="button"
                            onClick={() => alternarMenuAcciones(producto.id)}
                            aria-label={`Acciones de ${producto.nombre}`}
                            aria-expanded={
                              String(menuAccionesAbiertoId) ===
                              String(producto.id)
                            }
                          >
                            <FiMoreVertical aria-hidden="true" />
                          </button>
                          {String(menuAccionesAbiertoId) ===
                            String(producto.id) && (
                            <div className="admin-productos__acciones-menu">
                              <button
                                type="button"
                                onClick={() =>
                                  seleccionarAccion(() =>
                                    abrirModalEditarProducto(producto),
                                  )
                                }
                              >
                                Editar
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  seleccionarAccion(() =>
                                    manejarCambiarEstadoProducto(producto),
                                  )
                                }
                              >
                                {producto.activo ? "Desactivar" : "Activar"}
                              </button>
                              {puedeEliminarProductos && (
                                <button
                                  className="admin-productos__accion-peligrosa"
                                  type="button"
                                  onClick={() =>
                                    seleccionarAccion(() =>
                                      setProductoEliminar(producto),
                                    )
                                  }
                                >
                                  Eliminar
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="admin-productos__acciones-desktop">
                          <Boton
                            variante="admin"
                            onClick={() => abrirModalEditarProducto(producto)}
                          >
                            Editar
                          </Boton>
                          <Boton
                            variante="admin"
                            onClick={() =>
                              manejarCambiarEstadoProducto(producto)
                            }
                          >
                            {producto.activo ? "Desactivar" : "Activar"}
                          </Boton>
                          <Boton
                            variante="admin"
                            onClick={() => abrirModalVariante(producto.id)}
                          >
                            Agregar variante
                          </Boton>
                          {puedeEliminarProductos && (
                            <Boton
                              className="admin-productos__accion-peligrosa"
                              variante="admin"
                              onClick={() => setProductoEliminar(producto)}
                            >
                              Eliminar
                            </Boton>
                          )}
                        </div>
                      </div>
                    </article>
                    {String(productoVariantesAbiertoId) ===
                      String(producto.id) && (
                      <VariantesProducto
                        variantes={producto.variantes}
                        onEditar={abrirModalEditarVariante}
                        onCambiarEstado={manejarCambiarEstadoVariante}
                      />
                    )}
                  </Fragment>
                ))}
              </div>
              )}
              {!buscando && totalPaginas > 1 && (
                <nav
                  className="admin-productos__paginacion"
                  aria-label={modoVariantes ? "Paginación de variantes" : "Paginación de productos"}
                >
                  <span>
                    Mostrando{" "}
                    <strong>
                      {(pagina - 1) * TAMANIO_PAGINA + 1}–
                      {Math.min(pagina * TAMANIO_PAGINA, totalResultados)}
                    </strong>{" "}
                    de <strong>{totalResultados}</strong>{" "}
                    {modoVariantes
                      ? (totalResultados === 1 ? "variante" : "variantes")
                      : (totalResultados === 1 ? "producto" : "productos")}
                  </span>
                  <div className="estructura__panel-acciones">
                    <Boton
                      variante="admin"
                      disabled={pagina <= 1 || cargando || buscando}
                      onClick={() => cambiarPagina(pagina - 1)}
                    >
                      Anterior
                    </Boton>
                    <span>
                      Página {pagina} de {totalPaginas}
                    </span>
                    <Boton
                      variante="admin"
                      disabled={pagina >= totalPaginas || cargando || buscando}
                      onClick={() => cambiarPagina(pagina + 1)}
                    >
                      Siguiente
                    </Boton>
                  </div>
                </nav>
              )}
            </section>
          </>
        )}
      </Contenedor>
      {modalAbierto === "producto" && (
        <ModalAdmin
          titulo={productoEditandoId ? "Editar producto" : "Nuevo producto"}
          onClose={cerrarModal}
          formId="formulario-nuevo-producto"
        >
          <form
            id="formulario-nuevo-producto"
            className="estructura__formulario"
            onSubmit={manejarCrearProducto}
          >
            <div className="estructura__campo">
              <label htmlFor="producto-nombre">Nombre</label>
              <input
                id="producto-nombre"
                name="nombre"
                type="text"
                value={formProducto.nombre}
                onChange={manejarCampoProducto}
                onBlur={verificarNombreProducto}
                required
                autoFocus
              />
              {advertenciasNombre.map((advertencia) => (
                <p
                  key={`${advertencia.tipo}-${advertencia.producto.id}`}
                  className="admin-productos__advertencia"
                >
                  ⚠️{" "}
                  {advertencia.tipo === "exacta"
                    ? "Ya existe un producto con el mismo nombre:"
                    : "Existe un producto con un nombre similar:"}{" "}
                  <strong>{advertencia.producto.nombre}</strong>
                </p>
              ))}
            </div>
            <div className="estructura__campo">
              <label htmlFor="producto-marca">Marca</label>
              <select
                id="producto-marca"
                name="marca"
                value={formProducto.marca}
                onChange={manejarCampoProducto}
                required
              >
                <option value="">Seleccionar marca</option>
                {catalogosProducto?.marcas.map((marca) => (
                  <option key={marca.id} value={marca.nombre}>
                    {marca.nombre}
                  </option>
                ))}
              </select>
            </div>
            <div className="estructura__campo">
              <label htmlFor="producto-genero">Género</label>
              <select
                id="producto-genero"
                name="genero"
                value={formProducto.genero}
                onChange={manejarCampoProducto}
                required
              >
                <option value="">Seleccionar género</option>
                {catalogosProducto?.generos.map((genero) => (
                  <option key={genero.id} value={genero.nombre}>
                    {genero.nombre}
                  </option>
                ))}
              </select>
            </div>
            <div className="estructura__campo">
              <label htmlFor="producto-tipo">Tipo de producto</label>
              <select
                id="producto-tipo"
                name="tipoProducto"
                value={formProducto.tipoProducto}
                onChange={manejarCampoProducto}
                required
              >
                <option value="">Seleccionar tipo de producto</option>
                {catalogosProducto?.tiposProducto.map((tipoProducto) => (
                  <option key={tipoProducto.id} value={tipoProducto.nombre}>
                    {tipoProducto.nombre}
                  </option>
                ))}
              </select>
            </div>
            <div className="estructura__campo">
              <label htmlFor="producto-descripcion">Descripción</label>
              <textarea
                id="producto-descripcion"
                name="descripcion"
                value={formProducto.descripcion}
                onChange={manejarCampoProducto}
              />
            </div>
            <div className="estructura__campo">
              <label htmlFor="producto-activo">Activo</label>
              <input
                id="producto-activo"
                name="activo"
                type="checkbox"
                checked={formProducto.activo}
                onChange={manejarCampoProducto}
              />
            </div>
            {mensajeExito ? (
              <p className="estructura__tarjeta fondo-verde">{mensajeExito}</p>
            ) : (
              guardando && <p>Guardando...</p>
            )}
          </form>
        </ModalAdmin>
      )}
      {productoConfirmarEstado && (
        <ModalAdmin
          titulo="Desactivar producto"
          botonConfirmar="Desactivar"
          botonConfirmarDeshabilitado={
            String(procesandoProductoId) === String(productoConfirmarEstado.id)
          }
          onClose={() => setProductoConfirmarEstado(null)}
          formId="form-confirmar-desactivar-producto"
        >
          <form
            id="form-confirmar-desactivar-producto"
            onSubmit={async (e) => {
              e.preventDefault();
              await ejecutarCambioEstadoProducto(productoConfirmarEstado);
            }}
          >
            <div className="admin-productos__confirmacion">
              <p>
                ¿Estás seguro que deseas desactivar el producto{" "}
                <strong>{productoConfirmarEstado.nombre}</strong>?
              </p>
              <p>El producto no se eliminará. Simplemente quedará inactivo.</p>
            </div>
          </form>
        </ModalAdmin>
      )}
      {productoEliminar && (
        <ModalAdmin
          titulo="Eliminar producto"
          botonConfirmar="Eliminar"
          botonConfirmarDeshabilitado={
            String(procesandoProductoId) === String(productoEliminar.id)
          }
          onClose={() => setProductoEliminar(null)}
          formId="form-confirmar-eliminar-producto"
        >
          <form
            id="form-confirmar-eliminar-producto"
            onSubmit={async (e) => {
              e.preventDefault();
              await ejecutarEliminarProducto(productoEliminar);
            }}
          >
            <div className="admin-productos__confirmacion">
              <p>
                ¿Estás seguro que deseas eliminar el producto{" "}
                <strong>{productoEliminar.nombre}</strong>?
              </p>
              <p>
                El producto dejará de aparecer en el listado, pero conservará su
                registro en Vendure.
              </p>
            </div>
          </form>
        </ModalAdmin>
      )}
      {modalAbierto === "variante" && (
        <ModalAdmin
          titulo={varianteEditandoId ? "Editar variante" : "Nueva variante"}
          onClose={cerrarModal}
          formId="formulario-nueva-variante"
        >
          <form
            id="formulario-nueva-variante"
            className="estructura__formulario"
            onSubmit={manejarCrearVariante}
          >
            <div className="estructura__campo">
              <label htmlFor="variante-producto">Producto</label>
              <select
                id="variante-producto"
                name="productoId"
                value={formVariante.productoId}
                onChange={manejarCampoVariante}
                required
                disabled={Boolean(varianteEditandoId)}
                autoFocus
              >
                <option value="">Seleccionar producto</option>
                {productos.map((producto) => (
                  <option key={producto.id} value={producto.id}>
                    {producto.nombre}
                  </option>
                ))}
              </select>
            </div>
            {cargandoOpciones && <p>Cargando opciones del producto...</p>}
            {error && <p className="login-admin__error">{error}</p>}
            {mensajeExito && (
              <p className="estructura__tarjeta fondo-verde">{mensajeExito}</p>
            )}
            <div className="estructura__campo">
              <label htmlFor="variante-color">Color</label>
              <select
                id="variante-color"
                name="color"
                value={formVariante.color}
                onChange={(e) => seleccionarColor(e.target.value)}
                required
              >
                <option value="">Seleccionar color</option>
                {coloresDisponibles.map((color) => (
                  <option key={normalizarBusqueda(color)} value={color}>{color}</option>
                ))}
              </select>
            </div>
            <div className="estructura__campo">
              <label htmlFor="variante-talle">Talle</label>
              <input
                id="variante-talle"
                name="talle"
                type="text"
                value={formVariante.talle}
                onChange={manejarCampoVariante}
                onBlur={normalizarTalleIngresado}
                autoComplete="off"
              />
              {mostrarSugerenciasTalle &&
                tallesSugeridos.map((talle) => (
                  <div
                    className="estructura__lista-item"
                    key={normalizarBusqueda(talle)}
                  >
                    <button
                      className="estructura__tabla-boton"
                      type="button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => seleccionarTalle(talle)}
                    >
                      {talle}
                    </button>
                  </div>
                ))}
            </div>
            <div className="estructura__campo">
              <label htmlFor="variante-barcode">Barcode</label>
              <input
                id="variante-barcode"
                name="barcode"
                type="text"
                value={formVariante.barcode}
                onChange={manejarCampoVariante}
                autoComplete="off"
                required
              />
            </div>
            <div className="estructura__campo">
              <label htmlFor="variante-precio">Precio</label>
              <input
                id="variante-precio"
                name="precio"
                type="number"
                min="0"
                step="0.01"
                value={formVariante.precio}
                onChange={manejarCampoVariante}
                required={puedeModificarPrecios}
                disabled={!puedeModificarPrecios}
              />
              {!puedeModificarPrecios && (
                <span>Solo el administrador puede cargar o modificar precios.</span>
              )}
            </div>
            <SelectorImagen
              etiqueta="Fotografías del color"
              imagenesActuales={galeria.actuales}
              archivos={galeria.archivos}
              onCambiarGaleria={(actuales, archivos) => setGaleria({ actuales, archivos, modificada: true })}
              imagenActual={imagenVariante.actual}
              archivo={imagenVariante.archivo}
              onSeleccionarArchivo={manejarArchivoVariante}
              deshabilitado={guardando}
            />
            <div className="estructura__campo">
              <label htmlFor="variante-activo">Activo</label>
              <input
                id="variante-activo"
                name="activo"
                type="checkbox"
                checked={
                  !puedeModificarPrecios && !varianteEditandoId
                    ? false
                    : formVariante.activo
                }
                onChange={manejarCampoVariante}
                disabled={!puedeModificarPrecios && !varianteEditandoId}
              />
            </div>
            {guardando && <p>Guardando...</p>}
          </form>
        </ModalAdmin>
      )}
    </main>
  );
}
export default Productos;

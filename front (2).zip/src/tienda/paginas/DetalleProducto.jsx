
import { useEffect, useState } from 'react'
import {
  Link,
  useOutletContext,
  useParams,
} from 'react-router-dom'

import Boton from '../../componentesReuse/Boton'
import { obtenerDetalleProducto } from '../../servicios/catalogoService'

import '../../estilos/DetalleProducto.css'

const formatoPrecio = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
})

function DetalleProducto() {
  const { genero: generoRuta, productoId } = useParams()
  const genero = generoRuta || 'sale'

  const {
    agregarProductoAlCarrito,
    cargandoCarrito,
  } = useOutletContext()

  const [producto, setProducto] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [errorCarga, setErrorCarga] = useState('')

  const [colorId, setColorId] = useState('')
  const [talleId, setTalleId] = useState('')
  const [indiceImagen, setIndiceImagen] = useState(0)
  const [cantidad, setCantidad] = useState(1)

  const [agregando, setAgregando] = useState(false)
  const [errorCompra, setErrorCompra] = useState('')

  const nombreSEO = producto?.nombre
    ? producto.marca &&
      !producto.nombre.toLowerCase().includes(producto.marca.toLowerCase())
      ? `${producto.marca} ${producto.nombre}`
      : producto.nombre
    : ''

  useEffect(() => {
    const titulo = nombreSEO
      ? `${nombreSEO} | El Vestidor Tandil`
      : 'Producto | El Vestidor Tandil'

    const descripcion = nombreSEO
      ? `Comprá ${nombreSEO} en El Vestidor Tandil. Consultá colores, talles y disponibilidad, con envíos a todo el país.`
      : 'Consultá los productos de El Vestidor Tandil.'

    document.title = titulo

    let meta = document.querySelector('meta[name="description"]')

    if (!meta) {
      meta = document.createElement('meta')
      meta.name = 'description'
      document.head.appendChild(meta)
    }

    meta.content = descripcion

    let canonical = document.querySelector('link[rel="canonical"]')

    if (!canonical) {
      canonical = document.createElement('link')
      canonical.rel = 'canonical'
      document.head.appendChild(canonical)
    }

    canonical.href = `${window.location.origin}${window.location.pathname}`

    return () => {
      document.title = "El Vestidor Tandil | Levi's, EQUUS e indumentaria"
      meta.content = "Descubrí Levi's, EQUUS, indumentaria y calzado para mujer y hombre en El Vestidor Tandil. Explorá nuestra colección y comprá online."
      canonical.remove()
    }
  }, [nombreSEO])

  useEffect(() => {
    let activo = true

    async function cargarProducto() {
      setCargando(true)
      setErrorCarga('')
      setProducto(null)

      try {
        const resultado = await obtenerDetalleProducto(productoId)

        if (!activo) return

        setProducto(resultado)

        const primerColor =
          resultado.colores.find(color => color.disponible) ||
          resultado.colores[0]

        setColorId(
          primerColor
            ? String(primerColor.id ?? 'unico')
            : '',
        )

        setTalleId('')
        setIndiceImagen(0)
        setCantidad(1)
        setErrorCompra('')
      } catch (fallo) {
        if (activo) {
          setErrorCarga(
            fallo.message || 'No pudimos cargar el producto.',
          )
        }
      } finally {
        if (activo) {
          setCargando(false)
        }
      }
    }

    cargarProducto()

    return () => {
      activo = false
    }
  }, [productoId])

  const colorSeleccionado = producto?.colores.find(
    color => String(color.id ?? 'unico') === colorId,
  ) || null

  const variantesColor = colorSeleccionado?.variantes || []

  const tallesDisponibles = variantesColor.filter(
    variante => variante.disponible,
  )

  const varianteSeleccionada =
    variantesColor.find(
      variante =>
        String(variante.talleId ?? variante.id) === talleId,
    ) || null

  const imagenes = colorSeleccionado?.imagenes?.length
    ? colorSeleccionado.imagenes
    : producto?.imagenes || []

  const indiceActual =
    indiceImagen % Math.max(imagenes.length, 1)

  const imagenActual = imagenes[indiceActual] || null

  const precioReferencia =
    varianteSeleccionada ||
    tallesDisponibles[0] ||
    variantesColor[0]

  const porcentajeOferta = precioReferencia?.descuentoPorcentaje
  const precioOferta = precioReferencia?.precioOfertaEstimado

  const tieneOferta =
    Number.isInteger(porcentajeOferta) &&
    porcentajeOferta > 0 &&
    Number.isFinite(precioOferta) &&
    precioOferta < precioReferencia.precio

  const disponible = Boolean(
    varianteSeleccionada?.disponible,
  )

  function seleccionarColor(nuevoColorId) {
    setColorId(nuevoColorId)
    setTalleId('')
    setIndiceImagen(0)
    setCantidad(1)
    setErrorCompra('')
  }

  function seleccionarTalle(nuevoTalleId) {
    setTalleId(nuevoTalleId)
    setCantidad(1)
    setErrorCompra('')
  }

  function cambiarImagen(direccion) {
    if (imagenes.length <= 1) return

    setIndiceImagen(actual =>
      (actual + direccion + imagenes.length) %
      imagenes.length,
    )
  }

  function cambiarCantidad(direccion) {
    setCantidad(actual => Math.max(1, actual + direccion))
    setErrorCompra('')
  }

  async function agregarProducto() {
    if (agregando || cargandoCarrito) return

    if (!varianteSeleccionada) {
      setErrorCompra('Seleccioná un talle.')
      return
    }

    if (!disponible) {
      setErrorCompra('El talle seleccionado no tiene stock.')
      return
    }

    setAgregando(true)
    setErrorCompra('')

    try {
      await agregarProductoAlCarrito(
        varianteSeleccionada.id,
        cantidad,
      )
    } catch (fallo) {
      setErrorCompra(
        fallo.message || 'No pudimos agregar el producto.',
      )
    } finally {
      setAgregando(false)
    }
  }

  if (cargando) {
    return (
      <main className="detalle-producto">
        <div className="detalle-producto__contenedor">
          <p role="status">Cargando producto...</p>
        </div>
      </main>
    )
  }

  if (errorCarga || !producto) {
    return (
      <main className="detalle-producto">
        <div className="detalle-producto__contenedor">
          <p role="alert">
            {errorCarga || 'Producto no encontrado.'}
          </p>

          <Link to={`/${genero}`}>
            Volver al catálogo
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="detalle-producto">
      <div className="detalle-producto__contenedor">
        <nav
          className="detalle-producto__migas"
          aria-label="Ruta de navegación"
        >
          <Link to="/">Inicio</Link>
          <span aria-hidden="true">/</span>

          <Link to={`/${genero}`}>
            {genero}
          </Link>

          <span aria-hidden="true">/</span>
          <span aria-current="page">
            {producto.nombre}
          </span>
        </nav>

        <div className="detalle-producto__principal">
          <section
            className="detalle-producto__galeria"
            aria-label="Fotografías del producto"
          >
            <div className="detalle-producto__imagen-principal">
              {imagenActual ? (
                <img
                  src={imagenActual.url}
                  alt={`${producto.nombre} - ${colorSeleccionado?.nombre || ''}`}
                />
              ) : (
                <span>Sin imagen</span>
              )}

              {imagenes.length > 1 && (
                <div className="detalle-producto__flechas">
                  <button
                    type="button"
                    onClick={() => cambiarImagen(-1)}
                    aria-label="Fotografía anterior"
                  >
                    ‹
                  </button>

                  <button
                    type="button"
                    onClick={() => cambiarImagen(1)}
                    aria-label="Fotografía siguiente"
                  >
                    ›
                  </button>
                </div>
              )}
            </div>

            {imagenes.length > 1 && (
              <div className="detalle-producto__miniaturas">
                {imagenes.map((imagen, indice) => (
                  <button
                    key={`${imagen.id}-${indice}`}
                    type="button"
                    className={
                      indice === indiceActual
                        ? 'detalle-producto__miniatura detalle-producto__miniatura--activa'
                        : 'detalle-producto__miniatura'
                    }
                    onClick={() => setIndiceImagen(indice)}
                    aria-label={`Ver fotografía ${indice + 1}`}
                    aria-pressed={indice === indiceActual}
                  >
                    <img
                      src={imagen.url}
                      alt=""
                      loading="lazy"
                    />
                  </button>
                ))}
              </div>
            )}
          </section>

          <section className="detalle-producto__informacion">
            {producto.marca && (
              <span className="texto-etiqueta">
                {producto.marca}
              </span>
            )}

            <h1>{producto.nombre}</h1>

            {precioReferencia && (
              <p className="detalle-producto__precio" aria-live="polite">
                {tieneOferta ? (
                  <>
                    <strong
                      style={{
                        display: 'inline-block',
                        color: '#B5121B',
                        fontSize: 'clamp(1.5rem, 5vw, 2.1rem)',
                        fontWeight: 700,
                        lineHeight: 1.2,
                        marginRight: '0.75rem',
                      }}
                    >
                      {formatoPrecio.format(precioOferta)}
                    </strong>

                    <del
                      style={{
                        display: 'inline-block',
                        color: '#858585',
                        fontSize: '0.9rem',
                        fontWeight: 400,
                        marginRight: '0.75rem',
                      }}
                    >
                      {formatoPrecio.format(precioReferencia.precio)}
                    </del>

                    <span
                      style={{
                        display: 'inline-block',
                        backgroundColor: '#922F2F',
                        color: '#FFFFFF',
                        fontSize: '0.8rem',
                        fontWeight: 700,
                        padding: '0.3rem 0.5rem',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      -{porcentajeOferta}%
                    </span>
                  </>
                ) : (
                  formatoPrecio.format(precioReferencia.precio)
                )}
              </p>
            )}

            <div className="detalle-producto__campo">
              <h2>Color</h2>
              <div className="detalle-producto__opciones">
                {producto.colores.map(color => {
                  const id = String(color.id ?? 'unico')

                  return (
                    <button
                      key={id}
                      type="button"
                      className={
                        id === colorId
                          ? 'detalle-producto__opcion detalle-producto__opcion--activa'
                          : 'detalle-producto__opcion'
                      }
                      onClick={() => seleccionarColor(id)}
                      aria-pressed={id === colorId}
                    >
                      {color.nombre}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="detalle-producto__campo">
              <h2>Talle</h2>
              <div className="detalle-producto__opciones">
                {variantesColor.map(variante => {
                  const id = String(
                    variante.talleId ?? variante.id,
                  )

                  return (
                    <button
                      key={variante.id}
                      type="button"
                      className={
                        id === talleId
                          ? 'detalle-producto__opcion detalle-producto__opcion--activa'
                          : 'detalle-producto__opcion'
                      }
                      onClick={() => seleccionarTalle(id)}
                      disabled={!variante.disponible}
                      aria-pressed={id === talleId}
                    >
                      {variante.talle}
                    </button>
                  )
                })}
              </div>

              {tallesDisponibles.length === 0 && (
                <p className="detalle-producto__sin-stock">
                  No hay talles disponibles para este color.
                </p>
              )}
            </div>

            <div className="detalle-producto__campo">
              <h2>Cantidad</h2>
              <div className="detalle-producto__cantidad">
                <button
                  type="button"
                  onClick={() => cambiarCantidad(-1)}
                  disabled={cantidad <= 1}
                  aria-label="Disminuir cantidad"
                >
                  −
                </button>

                <output aria-live="polite">
                  {cantidad}
                </output>

                <button
                  type="button"
                  onClick={() => cambiarCantidad(1)}
                  disabled={!disponible}
                  aria-label="Aumentar cantidad"
                >
                  +
                </button>
              </div>
            </div>

            <Boton
              onClick={agregarProducto}
              disabled={
                !disponible ||
                agregando ||
                cargandoCarrito
              }
            >
              {agregando
                ? 'Agregando...'
                : 'Agregar al carrito'}
            </Boton>

            {errorCompra && (
              <p role="alert" className="detalle-producto__error">
                {errorCompra}
              </p>
            )}

            {producto.descripcion && (
              <div className="detalle-producto__descripcion">
                <h2>Descripción</h2>
                <div>{producto.descripcion}</div>
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  )
}

export default DetalleProducto
